<?php $__env->startSection('header'); ?>
    <a href="/surveyor/profile" class="nav-link"><i class="fas fa-chevron-left text-dark"></i></a>
    <span class="fw-bold">Profil</span>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container mt-3">
            <h1 class="fw-bold">Profil Edit</h1>
            <p style="color: #a5a5a5;">Edit profil Anda untuk melengkapi data pribadi.</p>
            <form action="/surveyor/profile/edit-profile" id="prf-edit-form" autocomplete="off" method="post"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <div class="admin row">
                    <input type="hidden" name="oldImage" value="<?php echo e($data->avatar); ?>">
                    <div class="form-group d-flex align-items-center mb-5">
                        <?php if($data->avatar): ?>
                            <img src="<?php echo e(asset('storage/' . $data->avatar)); ?>"
                                class="img-preview hl-img rounded-circle col-4 col-md-2"
                                style="width: 7.5em; height: 7.5em; object-fit: cover;">
                        <?php elseif($data->avatar): ?>
                            <img class="img-preview img-fluid hl-img rounded-circle col-3 col-md-2"
                                style="width: 7.5em; height: 7.5em; object-fit: cover;">
                        <?php else: ?>
                            <img src="/img/profile.png" alt="" class="img-preview hl-img rounded-circle col-3 col-md-2"
                                style="width: 7.5em; height: 7.5em; object-fit: cover;">
                        <?php endif; ?>

                        <div class="hl-upload col-9 ms-3">
                            <input class="inputfile <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="avatar"
                                name="avatar" onchange="previewImage()">
                            <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <label for="avatar" class="form-label fw-bold fs-6 btn btn-primary px-4 py-2 border-0"
                                style="border-radius: 0.5em; background: #3F4FC8;">Ubah Foto Profil</label>
                            <p class="upload ms-3">maks upload (2 Mb)</p>
                        </div>
                    </div>
                </div>
                <div class="bio-edit d-flex flex-md-row flex-column flex mt-4">
                    <input type="hidden" name="id" value="<?php echo e(auth()->user()->id); ?>">
                    <div class="bio-left row justify-content-center align-items-start align-items-sm-center m-2">
                        <div class="col-12 mb-3">
                            <label for="validationServer01" class="form-label fw-bold fs-6">Nama Lengkap</label>
                            <input type="text"
                                class="form-control border-primary <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="validationServer01" aria-describedby="validationServer01Feedback"
                                value="<?php echo e($data->nama_lengkap); ?>" name="nama_lengkap">
                            <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 mb-3">
                            <label for="validationServer02" class="form-label fw-bold fs-6">Tanggal Lahir</label>
                            <input type="date"
                                class="form-control border-primary <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="validationServer02" aria-describedby="validationServer02Feedback"
                                value="<?php echo e($data->tanggal_lahir); ?>" name="tanggal_lahir">
                            <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="bio-right row justify-content-center align-items-start align-items-sm-center m-2">
                        <div class="col-12 mb-3">
                            <label for="validationServer04" class="form-label fw-bold fs-6">Jenis Kelamin</label>
                            <select class="form-select w-100 border-primary <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="validationServer04" aria-describedby="validationServer04Feedback" name="gender">
                                <option disabled>Pilih...</option>
                                <option value="laki-laki" <?php echo e($data->gender == 'laki-laki' ? 'selected' : ''); ?>>
                                    Laki-laki
                                </option>
                                <option value="perempuan" <?php echo e($data->gender == 'perempuan' ? 'selected' : ''); ?>>
                                    Perempuan
                                </option>
                            </select>
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12 mb-3">
                            <label for="validationServer06" class="form-label fw-bold fs-6">Alamat</label>
                            <input type="text" class="form-control border-primary <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="validationServer06" aria-describedby="validationServer06Feedback"
                                value="<?php echo e($data->alamat); ?>" name="alamat">
                            <div id="validationServer06Feedback" class="invalid-feedback">
                                Harap berikan alamat yang valid.
                            </div>
                        </div>

                    </div>
                </div>
                <div class="submit mt-5">
                    <button type="submit" class="btn btn-md-lg btn-primary mb-5 h-auto mx-auto d-block px-4 py-2 border-0"
                        style="border-radius: 0.5rem; background: #3F4FC8;" id="submit">Simpan perubahan</button>
                </div>
            </form>
        </div>
    </div>
    <script>
        function previewImage() {
            const image = document.querySelector('#avatar');
            const imgPreview = document.querySelector('.img-preview');

            imgPreview.style.display = 'block';

            const oFReader = new FileReader();
            oFReader.readAsDataURL(image.files[0]);

            oFReader.onload = function(oFREvent) {
                imgPreview.src = oFREvent.target.result;
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/survey.idekite.id/resources/views/user/edit-profile.blade.php ENDPATH**/ ?>
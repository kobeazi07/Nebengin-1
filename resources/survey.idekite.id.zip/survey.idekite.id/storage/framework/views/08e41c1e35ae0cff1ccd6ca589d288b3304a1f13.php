<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Export Excel</title>

</head>


<body>
    <table border="1" cellspacing=0 cellpadding=5>
        <thead>
            <tr>
                <td colspan="<?php echo e(26 + count($fasos)); ?>">RESUME PENDATAAN PERUMAHAN DAN GANG DI KOTA
                    <?php echo e(strtoupper($datas[0]->kecamatan->kabupaten->nama)); ?>

                    KECAMATAN <?php echo e(strtoupper($datas[0]->kecamatan->nama)); ?>

                </td>
            </tr>
            <tr>
                <td colspan="<?php echo e(26 + count($fasos)); ?>">
                </td>
            </tr>
            <tr>
                <th rowspan="3">No</th>
                <th rowspan="3">Nama Perumahan dan Gang</th>
                <th rowspan="3">Lokasi Perumahan</th>
                <th colspan="2">Jenis Rumah</th>
                <th colspan="<?php echo e(count($fasos)); ?>">Jumlah Fasos</th>
                <th colspan="3">Jumlah Rumah</th>
                <th rowspan="3">Panjang Jalan Perumahan (m)</th>
                <th rowspan="3">Lebar Jalan Perumahan (m)</th>
                <th colspan="2">Kondisi Jalan</th>
                <th colspan="2">Panjang Saluran</th>
                <th colspan="2">Lebar Saluran</th>
                <th colspan="2">Kedalaman</th>
                <th colspan="2">Kondisi Saluran</th>
                <th colspan="4">Ruko Bagian Depan</th>
                <th rowspan="3">Pos Jaga</th>
                <th rowspan="3">Keterangan</th>
            </tr>
            <tr>
                <th rowspan="2">Developer</th>
                <th rowspan="2">Swadaya</th>
                <?php $__currentLoopData = $fasos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th rowspan="2"><?php echo e($item->jenis); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <th rowspan="2">Layak</th>
                <th rowspan="2">Tak Layak</th>
                <th rowspan="2">Kosong</th>
                <th rowspan="2">Baik</th>
                <th rowspan="2">Tidak Baik</th>
                <th rowspan="2">Kanan (m)</th>
                <th rowspan="2">Kiri (m)</th>
                <th rowspan="2">Kanan (m)</th>
                <th rowspan="2">Kiri(m)</th>
                <th rowspan="2">Kanan (m)</th>
                <th rowspan="2">Kiri(m)</th>
                <th rowspan="2">Baik</th>
                <th rowspan="2">Tidak Baik</th>
                <th colspan="2">Kanan</th>
                <th colspan="2">Kiri</th>
            </tr>
            <tr>
                <th>Unit</th>
                <th>Lantai</th>
                <th>Unit</th>
                <th>Lantai</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $iteration = 1;
                $sumDeveloper = 0;
                $sumSwadaya = 0;
                $sumFasos = 0;
                $sumLayak = 0;
                $sumTakLayak = 0;
                $sumKosong = 0;
                $sumPanjang = 0;
                $sumLebar = 0;
                $sumJalanBaik = 0;
                $sumJalanTidakBaik = 0;
                $sumSaluranPanjangKanan = 0;
                $sumSaluranPanjangKiri = 0;
                $sumSaluranLebarKanan = 0;
                $sumSaluranLebarKiri = 0;
                $sumSaluranKedalamanKanan = 0;
                $sumSaluranKedalamanKiri = 0;
                $sumSaluranBaik = 0;
                $sumSaluranTidakBaik = 0;
                $sumJumlahRukoKanan = 0;
                $sumLantaiRukoKanan = 0;
                $sumJumlahRukoKiri = 0;
                $sumLantaiRukoKiri = 0;
                $sumPos = 0;
            ?>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($iteration++); ?></td>
                    <td><?php echo e($data->nama_gang); ?></td>
                    <td><?php echo e($data->lokasi); ?></td>
                    <td><?php echo e($data->jumlah_rumah_developer); ?></td>
                    <?php
                        $sumDeveloper += $data->jumlah_rumah_developer;
                    ?>
                    <td><?php echo e($data->jumlah_rumah_swadaya); ?></td>
                    <?php
                        $sumSwadaya += $data->jumlah_rumah_swadaya;
                    ?>
                    <?php $__currentLoopData = $fasos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $i = 0;
                        ?>
                        <?php $__currentLoopData = $data->fasosTable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fasostabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->id == $fasostabel->jenis_fasos_id): ?>
                                <?php
                                    $i++;
                                ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php for($i; $i < $i; $i++): ?>
                        <?php endfor; ?>
                        <td><?php echo e($i ? $i : ''); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <td><?php echo e($data->jumlah_rumah_layak); ?></td>
                    <?php
                        $sumLayak += $data->jumlah_rumah_layak;
                    ?>
                    <td><?php echo e($data->jumlah_rumah_tak_layak); ?></td>
                    <?php
                        $sumTakLayak += $data->jumlah_rumah_tak_layak;
                    ?>
                    <td><?php echo e($data->jumlah_rumah_kosong); ?></td>
                    <?php
                        $sumKosong += $data->jumlah_rumah_kosong;
                    ?>
                    <td><?php echo e($data->dimensi_jalan_panjang); ?></td>
                    <?php
                        $sumPanjang += $data->dimensi_jalan_panjang;
                    ?>
                    <td><?php echo e($data->dimensi_jalan_lebar); ?></td>
                    <?php
                        $sumLebar += $data->dimensi_jalan_lebar;
                    ?>
                    <td><?php echo e($data->status_jalan ? $data->status_jalan : ''); ?>%</td>
                    <?php
                        $sumJalanBaik += $data->status_jalan;
                    ?>
                    <td><?php echo e(100 - $data->status_jalan); ?>%</td>
                    <?php
                        $sumJalanTidakBaik += 100 - $data->status_jalan;
                    ?>
                    <td><?php echo e($data->dimensi_saluran_panjang_kanan ? $data->dimensi_saluran_panjang_kanan : ''); ?>

                    </td>
                    <?php
                        $sumSaluranPanjangKanan += $data->dimensi_saluran_panjang_kanan;
                    ?>
                    <td><?php echo e($data->dimensi_saluran_panjang_kiri ? $data->dimensi_saluran_panjang_kiri : ''); ?></td>
                    <?php
                        $sumSaluranPanjangKiri += $data->dimensi_saluran_panjang_kiri;
                    ?>
                    <td><?php echo e($data->dimensi_saluran_lebar_kanan ? $data->dimensi_saluran_lebar_kanan : ''); ?></td>
                    <?php
                        $sumSaluranLebarKanan += $data->dimensi_saluran_lebar_kanan;
                    ?>
                    <td><?php echo e($data->dimensi_saluran_lebar_kiri ? $data->dimensi_saluran_lebar_kiri : ''); ?></td>
                    <?php
                        $sumSaluranLebarKiri += $data->dimensi_saluran_lebar_kiri;
                    ?>
                    <td><?php echo e($data->dimensi_saluran_kedalaman_kanan ? $data->dimensi_saluran_kedalaman_kanan : ''); ?>

                    </td>
                    <?php
                        $sumSaluranKedalamanKanan += $data->dimensi_saluran_kedalaman_kanan;
                    ?>
                    <td><?php echo e($data->dimensi_saluran_kedalaman_kiri ? $data->dimensi_saluran_kedalaman_kiri : ''); ?>

                    </td>
                    <?php
                        $sumSaluranKedalamanKiri += $data->dimensi_saluran_kedalaman_kiri;
                    ?>
                    <td><?php echo e($data->status_saluran ? $data->status_saluran : ''); ?>%</td>
                    <?php
                        $sumSaluranBaik += $data->status_saluran;
                    ?>
                    <td><?php echo e(100 - $data->status_saluran); ?>%</td>
                    <?php
                        $sumSaluranTidakBaik += 100 - $data->status_saluran;
                    ?>
                    <td><?php echo e($data->jumlah_ruko_kanan ? $data->jumlah_ruko_kanan : ''); ?></td>
                    <?php
                        $sumJumlahRukoKanan += $data->jumlah_ruko_kanan;
                    ?>
                    <td><?php echo e($data->lantai_ruko_kanan ? $data->lantai_ruko_kanan : ''); ?></td>
                    <?php
                        $sumLantaiRukoKanan += $data->lantai_ruko_kanan;
                    ?>
                    <td><?php echo e($data->jumlah_ruko_kiri ? $data->jumlah_ruko_kiri : ''); ?></td>
                    <?php
                        $sumJumlahRukoKiri += $data->jumlah_ruko_kiri;
                    ?>
                    <td><?php echo e($data->lantai_ruko_kiri ? $data->lantai_ruko_kiri : ''); ?></td>
                    <?php
                        $sumLantaiRukoKiri += $data->lantai_ruko_kiri;
                    ?>
                    <td><?php echo e($data->pos_jaga ? $data->pos_jaga : ''); ?></td>
                    <?php
                        $sumPos += $data->pos_jaga;
                    ?>
                    <td><?php echo e($data->catatan ? $data->catatan : ''); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="3">JUMLAH</td>
                <td><?php echo e($sumDeveloper); ?></td>
                <td><?php echo e($sumSwadaya); ?></td>
                <?php $__currentLoopData = $fasos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $i = 0;
                    ?>
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $data->fasosTable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fasostabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->id == $fasostabel->jenis_fasos_id): ?>
                                <?php
                                    $i++;
                                ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($i); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($sumLayak); ?></td>
                <td><?php echo e($sumTakLayak); ?></td>
                <td><?php echo e($sumKosong); ?></td>
                <td><?php echo e($sumPanjang); ?></td>
                <td><?php echo e($sumLebar); ?></td>
                <td><?php echo e(round($sumJalanBaik / count($datas), 2)); ?>%</td>
                <td><?php echo e(round($sumJalanTidakBaik / count($datas), 2)); ?>%</td>
                <td><?php echo e($sumSaluranPanjangKanan); ?></td>
                <td><?php echo e($sumSaluranPanjangKiri); ?></td>
                <td><?php echo e($sumSaluranLebarKanan); ?></td>
                <td><?php echo e($sumSaluranLebarKiri); ?></td>
                <td><?php echo e($sumSaluranKedalamanKanan); ?></td>
                <td><?php echo e($sumSaluranKedalamanKiri); ?></td>
                <td><?php echo e(round($sumSaluranBaik / count($datas), 2)); ?>%</td>
                <td><?php echo e(round($sumSaluranTidakBaik / count($datas), 2)); ?>%</td>
                <td><?php echo e($sumJumlahRukoKanan); ?></td>
                <td><?php echo e($sumLantaiRukoKanan); ?></td>
                <td><?php echo e($sumJumlahRukoKiri); ?></td>
                <td><?php echo e($sumLantaiRukoKiri); ?></td>
                <td><?php echo e($sumPos); ?></td>
                <td></td>
            </tr>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH D:\Laravel Project\survey-in\resources\views/admin/data-survei/view-cetak-resume-detail-data-survei.blade.php ENDPATH**/ ?>
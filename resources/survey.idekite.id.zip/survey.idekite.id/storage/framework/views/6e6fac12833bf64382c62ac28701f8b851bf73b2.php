<?php $__env->startSection('title', 'Surveyor'); ?>
<?php $__env->startSection('main-content'); ?>
<div class="content d-flex flex-column">
    <div class="surveyor-hl ms-0 ms-sm-5">
        <h1>Edit Profil Surveyor</h1>
        <p class="mb-5">Edit akun surveyor di bawah ini dengan benar</p>

        <!-- avatar -->
        <div class="surveyor">
            <?php if($profile->avatar): ?>
            <img src="<?php echo e(asset('storage/' . $profile->avatar)); ?> " class="profile-img rounded-circle">
            <?php else: ?>
            <img src="/img/profile.png" class="profile-img rounded-circle">
            <?php endif; ?>
        </div>
        <div class="profile-status mt-3 d-flex flex-column">
            <h3><?php echo e($profile->nama_lengkap); ?></h3>
            <p><?php echo e(ucwords($profile->role)); ?></p>
        </div>
    </div>
    <!-- Form Edit -->
    <form action="/surveyor/update" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <input type="hidden" name="target" value="2">
        <div class="row justify-content-evenly d-flex flex-column flex-sm-row">
            <div class="col-12 col-sm-5 mb-3">
                <input type="hidden" name="id" value="<?php echo e($profile->id); ?>">
                <div class="bio-left d-flex flex-column position-relative">
                    <label for="password" class="form-label fw-bold">Password</label>
                    <input type="password" class="form-control pe-5 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="password" name="password" placeholder="masukkan password" />
                    <i class="far fa-eye position-absolute p-1 mata-zaky" id="togglePassword"
                        style="top: 3.2em; right: 0; transform: scale(1.4);"></i>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="validationServer03Feedback" class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-12 col-sm-5">
                <div class="bio-right w-100 d-flex flex-column position-relative">
                    <label for="konfimasiPass" class="form-label fw-bold">Konfirmasi Password</label>
                    <input type="password" name="password_confirmation"
                        class="form-control pe-5 <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="password_confirmation" placeholder="konfirmasi password" />
                    <i class="far fa-eye position-absolute p-1 mata-zaky" id="togglePassword2"
                        style="top: 3.2em; right: 0; transform: scale(1.4);"></i>
                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="validationServer03Feedback" class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>          
        </div>

        <div class="row justify-content-center">
                <div class="col-5 mt-5 justify-content-center d-flex">
                    <input type="submit" value="Simpan Perubahan" class="btn btn-lg btn-primary mb-5 border-0 h-auto" style="border-radius: .5em; background: #3f4fc8;">
                </div>
        </div>
    </form>
</div>

<!-- =========== SCRIPT ============ -->
<script>
    const togglePassword = document.querySelector('#togglePassword');
        const password = document.querySelector('#password');

        togglePassword.addEventListener('click', function(e) {
            // toggle the type attribute
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            // toggle the eye slash icon
            this.classList.toggle('fa-eye-slash');
        });
</script>

<script>
    const togglePassword2 = document.querySelector('#togglePassword2');
        const password2 = document.querySelector('#password_confirmation');

        togglePassword2.addEventListener('click', function(e) {
            // toggle the type attribute
            const type = password2.getAttribute('type') === 'password' ? 'text' : 'password';
            password2.setAttribute('type', type);
            // toggle the eye slash icon
            this.classList.toggle('fa-eye-slash');
        });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/survey.idekite.id/resources/views/admin/surveyor/edit-password.blade.php ENDPATH**/ ?>
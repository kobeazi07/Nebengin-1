<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="/css/custom.css">
</head>

<body>
    <div class="data">
        <center><br>
            <h2 class="hh">DATA PRASARANA UTILITAS GANG DAN PERUMAHAN </h2>
            <h2>(<?php echo e($data->kecamatan->nama); ?>)</h2>
        </center><br>

        <center>
            <table align="center" cellspacing='0'>
                <tr valign='top'>
                    <td>Nama Gang atau Perumahan</td>
                    <td>:</td>
                    <td><?php echo e($data->nama_gang); ?></td>
                </tr>
                <tr valign='top'>
                    <td>Lokasi</td>
                    <td> : </td>
                    <td><?php echo e($data->lokasi); ?></td>
                </tr>
                <tr valign='top'>
                    <td>Koordinat</td>
                    <td>:</td>
                    <td>Depan = <?php echo e($data->no_gps_depan); ?> <br>
                        Belakang = <?php echo e($data->no_gps_belakang); ?>

                    </td>
                </tr>
                <tr valign='top'>
                    <td>Dimensi Jalan Utama</td>
                    <td>:</td>
                    <td>
                        Panjang = <?php echo e($data->dimensi_jalan_panjang); ?>m <br>
                        Lebar = <?php echo e($data->dimensi_jalan_lebar); ?>m
                    </td>
                </tr>
                <tr valign='top'>
                    <td>Kondisi Jalan</td>
                    <td>:</td>
                    <td>
                        <?php if($data->konstruksiJalan==null): ?>
                            Tidak ada
                        <?php else: ?>
                        <?php echo e($data->konstruksiJalan->jenis); ?> Kondisi <?php echo e($data->status_jalan); ?>%
                        <?php echo e($data->status_jalan >= 50 ? '(baik)' : '(buruk)'); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <tr valign='top'>
                    <td>Dimensi Saluran</td>
                    <td>:</td>
                    <td>
                        Panjang =
                        <?php echo e($data->dimensi_saluran_panjang_kanan != 0 ? $data->dimensi_saluran_panjang_kanan . ' m' : 'tidak ada'); ?>

                        (kanan) dan
                        <?php echo e($data->dimensi_saluran_panjang_kiri != 0 ? $data->dimensi_saluran_panjang_kiri . ' m' : 'tidak ada'); ?>

                        (kiri)<br>
                        Lebar =
                        <?php echo e($data->dimensi_saluran_lebar_kanan != 0 ? $data->dimensi_saluran_lebar_kanan . ' m' : 'tidak ada'); ?>

                        (kanan) dan
                        <?php echo e($data->dimensi_saluran_lebar_kiri != 0 ? $data->dimensi_saluran_lebar_kiri . ' m' : 'tidak ada'); ?>

                        (kiri)<br>
                        Kedalaman =
                        <?php echo e($data->dimensi_saluran_kedalaman_kanan != 0 ? $data->dimensi_saluran_kedalaman_kanan . ' m' : 'tidak ada'); ?>

                        (kanan) dan
                        <?php echo e($data->dimensi_saluran_kedalaman_kiri != 0 ? $data->dimensi_saluran_kedalaman_kiri . ' m' : 'tidak ada'); ?>

                        (kiri)<br>
                    </td>
                </tr>
                <tr valign='top'>
                    <td>Kondisi Saluran</td>
                    <td>:</td>
                    <td>
                        <?php if($data->konstruksiSaluran==null): ?>
                            Tidak Ada
                        <?php else: ?>
                            <?php echo e($data->konstruksiSaluran->jenis); ?> Kondisi <?php echo e($data->status_saluran); ?>%
                            <?php echo e($data->status_saluran >= 50 ? '(baik)' : '(buruk)'); ?>

                        <?php endif; ?>
                    </td>
                </tr>
                <tr valign='top'>
                    <td>Fasos</td>
                    <td>:</td>
                    <td>
                        <?php if(count($data->fasosTable) == 0): ?>
                            Tidak ada
                        <?php else: ?>
                            <?php $__currentLoopData = $data->fasosTable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <b><?php echo e($item->jenisFasos->jenis); ?> :</b>
                                <table>
                                    <tr>
                                        <td style="padding: 0 10px"></td>
                                        <td>Koordinat</td>
                                        <td>=</td>
                                        <td><?php echo e($item->koordinat_fasos); ?></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 0 10px"></td>
                                        <td>Panjang</td>
                                        <td>=</td>
                                        <td><?php echo e($item->panjang); ?> m</td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 0 10px"></td>
                                        <td>Lebar</td>
                                        <td>=</td>
                                        <td><?php echo e($item->lebar); ?> m</td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 0 10px"></td>
                                        <td>Luas</td>
                                        <td>=</td>
                                        <td><?php echo e($item->lebar * $data->fasosTable[$loop->index]->panjang); ?> m</td>
                                    </tr>
                                </table>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr valign='top'>
                    <td>Jumlah Rumah</td>
                    <td> : </td>
                    <td>
                        <table>
                            <tr>
                                <td>Layak </td>
                                <td>=</td>
                                <td><?php echo e($data->jumlah_rumah_layak); ?> Unit</td>
                            </tr>
                            <tr>
                                <td>Tidak Layak</td>
                                <td>=</td>
                                <td><?php echo e($data->jumlah_rumah_tak_layak); ?> Unit</td>
                            </tr>
                            <tr>
                                <td>Kosong</td>
                                <td>=</td>
                                <td><?php echo e($data->jumlah_rumah_kosong); ?> Unit</td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr valign='top'>
                    <td>Jenis Rumah</td>
                    <td> : </td>
                    <td>
                        <table>
                            <tr>
                                <td>Developer</td>
                                <td>=</td>
                                <td><?php echo e($data->jumlah_rumah_developer); ?> Unit</td>
                            </tr>
                            <tr>
                                <td>Swadaya</td>
                                <td>=</td>
                                <td><?php echo e($data->jumlah_rumah_swadaya); ?> Unit</td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr valign='top'>
                    <td>Pos Jaga</td>
                    <td>:</td>
                    <td>
                        <?php echo e($data->pos_jaga == 1 ? 'Ada' : 'Tidak Ada'); ?>

                    </td>
                </tr>
                <tr valign='top'>
                    <td>Ruko di Bagian Depan</td>
                    <td>:</td>
                    <td>
                        <table>
                            <tr>
                                <td>
                                    Kanan =
                                    <?php if($data->jumlah_ruko_kanan == 0): ?>
                                        tidak ada
                                    <?php else: ?>
                                        <?php echo e($data->jumlah_ruko_kanan); ?> unit <?php echo e($data->lantai_ruko_kanan); ?> lantai
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Kiri =
                                    <?php if($data->jumlah_ruko_kiri == 0): ?>
                                        tidak ada
                                    <?php else: ?>
                                        <?php echo e($data->jumlah_ruko_kiri); ?> unit <?php echo e($data->lantai_ruko_kiri); ?> lantai
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr valign='top'>
                    <td>No IMB Pendahuluan</td>
                    <td>:</td>
                    <td>
                        <?php echo e($data->no_imb != 0 ? $data->no_imb : '-'); ?>

                    </td>
                </tr>
                <tr valign='top'>
                    <td>Catatan</td>
                    <td>:</td>
                    <td style="max-width: 30px">
                        <?php echo e($data->catatan); ?>

                    </td>
                </tr>
                <tr valign='top'>
                    <td>Lampiran Data</td>
                    <td>:</td>
                    <td>
                        <?php echo e(count($data->lampiranFoto) == 0 && count($data->fasosTable) == 0 ? '-' : ''); ?>

                    </td>
                </tr>
            </table>
            <table width='100%' align="center">
                
                <?php $__currentLoopData = $data->fasosTable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->iteration % 2 == 1): ?>
                        <tr>
                    <?php endif; ?>
                    <td align="center" style="padding: 10px">
                        <h3 style="text-align: center"><?php echo e($item->jenisFasos->jenis); ?></h3>
                        <img src="<?php echo e(asset('storage/' . $item->foto)); ?>" width="300px" height="200px">
                    </td>
                    <?php if($loop->iteration % 2 == 0 || $loop->iteration == count($data->fasosTable) + 1): ?>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <table align='center' width="100%">
                
                <?php $__currentLoopData = $data->lampiranFoto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->iteration % 2 == 1 || $loop->iteration == count($data->lampiranFoto) + 1): ?>
                        <tr>
                    <?php endif; ?>
                    <td align="center" style="padding: 10px">
                        <h3 style="text-align: center"><?php echo e($item->jenisLampiran->jenis); ?></h3>
                        <img src="<?php echo e(asset('storage/' . $item->foto)); ?>" width="300px" height="200px">
                    </td>
                    <?php if($loop->iteration % 2 == 0 || $loop->iteration == count($data->lampiranFoto) + 1): ?>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </center>
    </div>
</body>

</html>
<?php /**PATH /www/wwwroot/survey.idekite.id/resources/views/admin/data-survei/cetak-detail.blade.php ENDPATH**/ ?>
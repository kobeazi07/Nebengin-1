<?php $__env->startSection('title','Surveyor'); ?>
<?php $__env->startSection('main-content'); ?>
<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content -->
<div class="content d-flex flex-column">
    <div class="admin-hl text-center ">
        <h1>Akun Surveyor</h1>
        <p>Dibawah ini merupakan kumpulan akun <br>surveyor yang ada pada saat ini:</p>
    </div>

    <!-- Button Tambah -->
    
    <div class="btn-content text-end  me-5 mb-5 mt-3">
        <a href="/surveyor/tambah" class="btn-tambah shadow text-decoration-none text-white ">+Tambah Akun</a>
    </div>

    <!-- Daftar AKun -->
    <div class="daftar-akun p-0 m-0">
        <!-- Akun Surveyor 1 -->
        <?php $__currentLoopData = $surveyors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surveyor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="akun-surveyor d-flex justify-content-between align-items-center flex-md-row flex-column p-2 m-0 pb-2 mb-2 p-sm-3 m-sm-3">
            <div class="nama-akun">
                <?php echo e($surveyor->nama_lengkap); ?>

            </div>
            <div class="tindakan d-flex flex-row">
                <a href="/surveyor/profile/<?php echo e($surveyor->id); ?>" class="btn-aksi profil text-decoration-none">Profil</a>
                <a href="/surveyor/target/<?php echo e($surveyor->id); ?>" class="btn-aksi target  text-decoration-none">Target</a>
                <button class="btn-aksi hapus btn-hapus-surveyor" data-bs-toggle="modal" data-bs-target="#hapusSurveyor"
                    value="<?php echo e($surveyor->id); ?>">Hapus</button>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>
<div class="modal fade" id="hapusSurveyor" tabindex="-1" aria-labelledby="hapusSurveyor" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content border-0">
            <div class="modal-body">
                <p class="p text-center mt-4">Anda yakin ingin hapus<br> Akun Surveyor <span id="nama"
                        class="fw-bolder"></span> ?</p>
            </div>
            <form action="/surveyor/hapus" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <input type="hidden" name="id" id="idSurveyor">
                <div class="choose d-flex justify-content-center gap-5 mb-5">
                    <button type="button" class="btn btn-secondary btn-lg ps-4 pe-4 shadow-none border-0" id="cancel"
                        data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-alert btn-lg ps-3 pe-3 shadow-none border-0 text-light"
                        id="exit">Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
            $(".btn-hapus-surveyor").click(function (e) {
                $('#idSurveyor').attr('value', e.target.value);
                $('#nama').text($(this).parent().siblings().text());
            });
        });
</script>
<!-- Contntet End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\survey.idekite.id\resources\views/admin/surveyor.blade.php ENDPATH**/ ?>
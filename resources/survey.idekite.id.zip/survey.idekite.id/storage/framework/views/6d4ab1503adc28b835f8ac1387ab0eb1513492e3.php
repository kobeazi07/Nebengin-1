<?php $__env->startSection('title','Surveyor'); ?>
<?php $__env->startSection('main-content'); ?>
<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- content -->
<div class="content d-flex flex-column">
    <div class="surveyor-hl ms-0 ms-sm-5">
        <h1>Tambah Target Surveyor</h1>
        <p class="mb-5">Tentukan targer survey per surveyor di bawah ini </p>

        <!-- avatar -->
        <div class="surveyor">
            <?php if($profile_surveyor->avatar): ?>
                <img src="<?php echo e(asset('storage/' . $profile_surveyor->avatar)); ?> " class="profile-img rounded-circle">
                <?php else: ?>
                <img src="/img/profile.png" class="profile-img rounded-circle">
                <?php endif; ?>
        </div>
        <div class="profile-status mt-3 d-flex flex-column">
            <h3><?php echo e(ucwords($profile_surveyor->nama_lengkap)); ?></h3>
            <p><?php echo e(ucwords($profile_surveyor->role)); ?></p>
        </div>
    </div>

    <!-- Form -->
    <form action="/surveyor/tambah-target" method="POST" class="bio-edit d-flex m-0 m-sm-5" autocomplete="off">
        <?php echo csrf_field(); ?>
        <div class="bio-left col-12 col-sm-6 d-flex flex-column">
            <input type="hidden" name="id" value="<?php echo e($profile_surveyor->id); ?>">
            <div class="col-md-8 mb-3 w-100">
                <label for="validationServer03" class="form-label">Kecamatan</label>
                <select class="form-select <?php $__errorArgs = ['kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kecamatan" id="kecamatan">
                    <option value="" selected disabled>--Pilih Kecamatan--</option>
                    <?php $__currentLoopData = $kecamatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($kecamatan->id); ?>"><?php echo e($kecamatan->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="validationServer03Feedback" class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3 w-100 d-flex flex-column flex-sm-row justify-content-between">
                <div class="target-kecamatan col-12 col-sm-5 me-5">
                    <label for="validationServer03" class="form-label">Kategori</label>
                    <select class="form-control form-control" id="validationServer03"
                        aria-label="Default select example " name="kategori">
                        <option value="6">Perminggu</option>
                    </select>
                </div>

                <div class="target-tanggal col-12 col-sm-5 ms-0 ms-sm-4">
                    <label for="validationServer03" class="form-label date-target">Tanggal Mulai</label>
                    <input type="date" class="form-control <?php $__errorArgs = ['tanggal_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="tanggal_mulai" value="<?php echo e(date('Y-m-d')); ?>">
                    <?php $__errorArgs = ['tanggal_mulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="validationServer03Feedback" class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="col-md-8 mb-3 w-75 d-flex align-items-end">
                <div class="jumlah-target w-75 me-4">
                    <label for="validationServer03" class="form-label">Jumlah Target</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['target'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        id="validationServer03" name="target" value="10">
                    <?php $__errorArgs = ['target'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div id="validationServer03Feedback" class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <span class="keterangan-target w-100 ">
                    <p>Gang dan Perumahan</p>
                </span>

            </div>
            <div class="tambah-akun mt-4">
                <button type="submit" class="btn btn-lg btn-primary mb-5 fs-6 w-100 border-0"
                    id="tambah-akun-surveyor">Simpan</button>
            </div>
        </div>
    </form>
    <!-- Form End -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/survey.idekite.id/resources/views/admin/surveyor/add-surveyor-target.blade.php ENDPATH**/ ?>
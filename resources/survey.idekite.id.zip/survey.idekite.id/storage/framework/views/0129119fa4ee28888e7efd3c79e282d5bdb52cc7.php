
<?php $__env->startSection('title','Surveyor'); ?>
<?php $__env->startSection('main-content'); ?>
<div class="content">
    <div class="row justify-content-start">
        <div class="col-10">
            <div class="surveyor-hl ms-0 ms-sm-5">
                <h1>Edit Profile Surveyor</h1>
                <p class="mb-5">Edit akun surveyor di bawah ini dengan benar</p>

                <!-- avatar -->
                <div class="surveyor">
                    <?php if($profile->avatar): ?>
                    <img src="<?php echo e(asset('storage/' . $profile->avatar)); ?> " class="profile-img rounded-circle">
                    <?php else: ?>
                    <img src="/img/profile.png" class="profile-img rounded-circle">
                    <?php endif; ?>
                </div>
                <div class="profile-status mt-3 d-flex flex-column">
                    <h3><?php echo e($profile->nama_lengkap); ?></h3>
                    <p><?php echo e(ucwords($profile->role)); ?></p>
                </div>
            </div>
        </div>
        <div class="col-12  p-0 p-sm-5">
            <form method="POST" action="/surveyor/update">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="bio-edit d-flex flex-sm-row flex-column flex mt-4">
                    <div class="bio-left w-100 d-flex flex-column align-items-start align-items-sm-center">
                        <div class="col-10 mb-3 m-3">
                            <input type="hidden" name="target" value="1">
                            <div class="mb-3">
                                <input type="hidden" name="id" value="<?php echo e($profile->id); ?>">
                                <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="nama_lengkap" name="nama_lengkap" value="<?php echo e($profile->nama_lengkap); ?>">
                                <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="validationServer03Feedback" class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-10 mb-3 m-3">
                            <div class="mb-3">
                                <label class="form-label">Area Survei</label>
                                <select class="form-control form-select <?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> py-2"
                                    id="area" name="area">
                                    <?php $__currentLoopData = $kabupaten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e(($item->id==$profile->kabupaten_id)?'selected':''); ?> class="form-control" ><?php echo e($item->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="validationServer03Feedback" class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="bio-right w-100 d-flex flex-column align-items-start align-items-sm-center">
                        <div class="col-10 mb-3">
                            <div class="mb-3 m-3">
                                <label for="nomor_telpon" class="form-label">Nomor Telepon</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['nomor_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="nomor_telepon" name="nomor_telepon" value="<?php echo e($profile->nomor_telepon); ?>">
                                <?php $__errorArgs = ['nomor_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="validationServer03Feedback" class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-10 mb-3">
                            <div class="mb-3 m-3">
                                <label for="email" class="form-label">Email address</label>
                                <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email"
                                    name="email" value="<?php echo e($profile->email); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="validationServer03Feedback" class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row justify-content-center col-12">
                    <div class="col-10 col-sm-5 mt-5 ps-0 pe-0">
                        <input type="submit" value="Simpan Perubahan"
                            class="btn btn-lg btn-primary mb-5 h-auto h-auto border-0 col-11" style="border-radius: .5em; background: #3f4fc8;">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Project\survey-in\resources\views\admin\surveyor\edit-profile.blade.php ENDPATH**/ ?>
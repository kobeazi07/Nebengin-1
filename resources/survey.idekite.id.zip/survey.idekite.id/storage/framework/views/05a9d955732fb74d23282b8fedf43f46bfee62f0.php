
<?php $__env->startSection('title', 'Surveyor'); ?>
<?php $__env->startSection('main-content'); ?>
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- content -->
    <div class="content d-flex flex-column" id="surveyor-profile">
        <div class="surveyor-hl ms-0 ms-sm-5">
            <h1>Profil Surveyor</h1>
            <p class="mb-5">Dibawah ini adalah informasi lengkap <br> dari surveyor</p>

            <!-- avatar -->
            <div class="surveyor">
                <?php if($profile_surveyor->avatar): ?>
                <img src="<?php echo e(asset('storage/' . $profile_surveyor->avatar)); ?> " class="profile-img rounded-circle">
                <?php else: ?>
                <img src="/img/profile.png" class="profile-img rounded-circle">
                <?php endif; ?>
            </div>
            <div class="profile-status mt-3 d-flex flex-column">
                <h3><?php echo e(ucwords($profile_surveyor->nama_lengkap)); ?></h3>
                <p><?php echo e(ucwords($profile_surveyor->role)); ?></p>
            </div>
        </div>

        <div class="data-surveyor p-0 p-sm-5">
            <!-- Riwayat -->
            <div class="riwayat d-flex justify-content-end mb-2" data-bs-toggle="modal" data-bs-target="#riwayatModal">
                <span data-bs-toggle="modal" data-bs-target="#surveyModal" class="me-2 btn btn-outline-primary" >Riwayat Survey</span>
                <span data-bs-toggle="modal" data-bs-target="#riwayatModal" class="me-1 btn btn-outline-primary ">Riwayat Target</span> 
            </div>
            <input type="hidden" value="<?php echo e($profile_surveyor->id); ?>" id="data-id">
            <!-- Modal Riwayat Target -->
            <div class="modal fade mt-0" id="riwayatModal" tabindex="-1" aria-labelledby="riwayatModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-xl modal-dialog-scrollable">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="riwayatModalLabel">Riwayat Target</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="container-tabel">
                                <table class="table" id="tabel-riwayat">
                                    <thead class="judul-tabel border-bottom-1">
                                        <tr>
                                            <th class="p-0" scope="col">Surveyor</th>
                                            <th class="p-0" scope="col">Kecamatan</th>
                                            <th class="p-0" scope="col">Jenis Target</th>
                                            <th class="p-0" scope="col">Tanggal Mulai</th>
                                            <th class="p-0" scope="col">Tanggal Selesai</th>
                                            <th class="p-0" scope="col">Hasil Target</th>
                                            <th class="p-0" scope="col">Perhitungan Target</th>
                                        </tr>
                                    </thead>
                                    <tbody class="isi-tabel">
                                        <?php $__currentLoopData = $detailSurvey; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($profile_surveyor->nama_lengkap); ?></td>
                                                <td><?php echo e($item->kecamatan->nama); ?></td>
                                                <td>
                                                    <?php
                                                        $selisih=\Carbon\Carbon::createFromTimestamp(strtotime($item->tanggal_mulai))->diff(\Carbon\Carbon::createFromTimestamp(strtotime($item->tanggal_selesai)))->days;
                                                        $selisih= $selisih+1;
                                                    ?>
                                                    <?php if($selisih !=6 && $selisih !=7): ?>
                                                        <?php echo e($selisih); ?> hari
                                                    <?php else: ?>
                                                        Per-minggu
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e(\Carbon\Carbon::parse($item->tanggal_mulai)->format('j F Y')); ?>

                                                </td>
                                                <td><?php echo e(\Carbon\Carbon::parse($item->tanggal_selesai)->format('j F Y')); ?>

                                                </td>

                                                <td><?php echo e($item->selesai); ?> dari <?php echo e($item->target); ?> Gang dan Perumahan
                                                </td>
                                                <td
                                                    class="<?php echo e($item->selesai - $item->target < 0 ? 'text-danger' : 'text-success'); ?> fw-bold">
                                                    <?php if($item->selesai - $item->target > 0): ?>
                                                        + <?php echo e($item->selesai - $item->target); ?> Gang dan Perumahan
                                                    <?php elseif($item->selesai - $item->target == 0): ?>
                                                        Survey Sukses
                                                    <?php elseif($item->selesai - $item->target < 0): ?>
                                                        <?php echo e($item->selesai - $item->target); ?>

                                                        Gang dan Perumahan
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Modal Riwayat Target -->
            <!-- Modal Riwayat Survey -->
            <div class="modal fade mt-0" id="surveyModal" tabindex="-1" aria-labelledby="riwayatModalLabelSurvey aria-hidden="true">
                <div class="modal-dialog modal-xl modal-dialog-scrollable">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="riwayatModalLabel">Riwayat Survey <?php echo e($profile_surveyor->nama_lengkap); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="container-tabel">
                                <div class="pilih w-100 d-flex flex-column container-fluid">
                                    <h1 class="dasur-content w-100 text-center mt-4">
                                        Pencarian Hasil Survey
                                    </h1>
                                    <p class="dasur-content w-100 text-center mb-4">
                                        Temukan hasil Survey Gang dan Perumahan <br> di Kecamatan <span class="text-kec"></span>
                                    </p>
                                        <div class="row justify-content-around my-3 col-12 d-flex flex-column flex-sm-row">
                                            <div class="col-sm-5 col-12">
                                                <div class="input-group mb-3">
                                                    <label class="input-group-text fw-bold" for="kabupaten">Kabupaten/Kota</label>
                                                    <select class="form-select" id="kabupaten" name="kabupaten">
                                                        <option selected>Pilih kota/kabupaten</option>
                                                        <?php $__currentLoopData = $kabupaten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>">
                                                                <?php echo e($item->nama); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-5 col-12">
                                                <div class="input-group mb-3">
                                                    <label class="input-group-text fw-bold" for="kecamatan">Kecamatan</label>
                                                    <select class="form-select" id="kecamatan" name="kecamatan">
                                                        <option value="" selected> Pilih Kecamatan</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                                <div class="form-dasur ps-4 pe-4 mb-4 mt-4">
                                    <table class="table table-hover bg-white shadow-sm table-responsive flex-column" id="dasur-table" style="width: 100%;">
                                        <thead>
                                            <tr style="vertical-align: middle">
                                                <th scope="col" style="width: 20%;">Nama Gang dan Perumahan</th>
                                                <th scope="col" style="width: 21%;">Lokasi</th>
                                                <th scope="col" style="width: 20%;">Kecamatan</th>
                                                <th scope="col" style="width: 15%;">koordinat Depan</th>
                                                <th scope="col" style="width: 25%;">Aktivitas</th>
                                            </tr>
                                        </thead>
                                        <tbody id="data" class="data">
                                            <script type="module" src="/js/data-survei-single.js"></script>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Modal Riwayat Survey -->


            <!--  Data Profil Surveyor -->
            <div class="biodata p-0 p-sm-3">
                <table class="bio">
                    <tr>
                        <td class="left-bio">Nama Lengkap</td>
                        <td style="width: 3%;" class="pe-1 ps-1 align-top">:</td>
                        <td class="right-bio align-top"><?php echo e(ucwords($profile_surveyor->nama_lengkap)); ?></td>
                    </tr>
                    <tr>
                        <td class="left-bio">Wilayah Survey</td>
                        <td style="width: 1%;" class="pe-1 ps-1 align-top">:</td>
                        <td class="right-bio align-top">Kabupaten <?php echo e(ucwords($area->nama)); ?></td>
                    </tr>
                    <tr>
                        <td class="left-bio">Email</td>
                        <td style="width: 1%;" class="pe-1 ps-1 align-top">:</td>
                        <td class="right-bio align-top"><?php echo e($profile_surveyor->email); ?></td>
                    </tr>
                    <tr>
                        <td class="left-bio">No. Handphone</td>
                        <td style="width: 1%;" class="pe-1 ps-1 align-top">:</td>
                        <td class="right-bio align-top"><?php echo e($profile_surveyor->nomor_telepon); ?></td>
                    </tr>
                    <tr class="w-100">
                        <td class="left-bio">Alamat</td>
                        <td style="width: 1%;" class="pe-1 ps-1 align-top">:</td>
                        <td class="right-bio text-wrap align-top">
                            <?php echo e($profile_surveyor->alamat); ?></td>
                    </tr>
                    <tr>
                        <td class="left-bio">Jenis Kelamin</td>
                        <td style="width: 1%;" class="pe-1 ps-1 align-top">:</td>
                        <td class="right-bio align-top"><?php echo e(ucwords($profile_surveyor->gender)); ?></td>
                    </tr>
                    <tr>
                        <td class="left-bio">Tanggal Lahir</td>
                        <td style="width: 1%;" class="pe-1 ps-1 align-top">:</td>
                        <td class="right-bio align-top">
                            <?php echo e($profile_surveyor->tanggal_lahir === null ? $profile_surveyor->tanggal_lahir : \Carbon\Carbon::parse($profile_surveyor->tanggal_lahir)->format('j F Y')); ?>

                        </td>
                    </tr>
                    <tr>
                        <td class="left-bio">Target Mingguan</td>
                        <td style="width: 1%;" class="pe-1 ps-1 align-top">:</td>
                        <td class="right-bio align-top"><?php echo e($weekly_selesai); ?> dari
                            <?php echo e($weekly_target); ?> Gang dan Perumahan</td>
                    </tr>
                    <tr>
                        <td class="left-bio">Target Tercapai</td>
                        <td style="width: 1%;" class="pe-1 ps-1 align-top">:</td>
                        <td class="right-bio align-top"><?php echo e($selesai); ?> dari
                            <?php echo e($target); ?> Gang dan Perumahan </td>
                    </tr>
                    <tr id="tr-akhir">
                        <td class="left-bio">Perhitungan Target</td>
                        <td style="width: 1%;" class="pe-1 ps-1 align-top">:</td>
                        <td class="right-bio <?php echo e($selesai - $target < 0 ? 'text-danger' : 'text-success'); ?> fw-bold align-top">
                            <?php if($selesai - $target > 0): ?>
                                + <?php echo e($selesai - $target); ?> Gang dan Perumahan
                            <?php elseif($selesai - $target == 0): ?>
                                Survey Komplit
                            <?php elseif($selesai - $target < 0): ?> <?php echo e($selesai - $target); ?> Gang dan Perumahan
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- Btn Ubah Password -->
        <div class="ubah-password d-flex justify-content-evenly mt-5">
            <a href="/surveyor/edit/profile/<?php echo e($profile_surveyor->id); ?>" class="btn btn-primary ps-2 pe-2 ps-sm-5 pe-sm-5 mb-5 border-0 h-auto" style="border-radius: .5em; background: #3f4fc8;">Edit
                Profile</a>
            <a href="/surveyor/edit/password/<?php echo e($profile_surveyor->id); ?>" class="btn btn-primary ps-2 pe-2 ps-sm-5 pe-sm-5 mb-5 border-0 h-auto" style="border-radius: .5em; background: #3f4fc8;">Edit
                Password</a>
        </div>
        <script>
            $(window).ready(function() {
                $("#dasur-table").click(function(e) {
                    let btn = e.target;
                    if (btn.classList.contains('btn-hapus')) {
                        $('#hapus-id').attr('value', btn.value);
                    }
                })
            });
        </script>
        <script src="/js/jquery.dataTables.min.js"></script>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel Project\survey-in\resources\views/admin/surveyor/surveyor-profile.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers\API;
use App\Models\Trip;
use App\Models\RequestTrip;
use App\Models\TripPenumpang;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\ApiTripRequest;
use App\Http\Requests\ApiTripPRequest;
use App\Http\Requests\ApiPembatalanRequest;
class TripController extends Controller
{
    public function showtrip(){
        $trip = Trip::get();
        return response()->json([
                'trips'=>$trip
        ]);
    }

    public function showtrippenumpang(){
        $penumpangtrip = TripPenumpang::get();
        return response()->json([
                'trip_penumpangs'=>$penumpangtrip
        ]);
    }
    public function tambahtrippenumpang(ApiTripRequest $request, $id){
        $valid = $request->validated();
        // $this->registerValidation($request->all());
        DB::beginTransaction();
        try{

            if($request->file('foto_barangb')){
                $bukti_barang= $request->file('foto_barangb');
                $filename= 'TripPenumpang-'. $bukti_barang->getClientOriginalName();
                $bukti_barang->move(public_path('inputan/img/trip_penumpang'), $filename);
            }
       
            $trip_penumpang = TripPenumpang::where('id',$id)->update([
                // users_id
                // trips_id
                // catatan_lokasi
                // kursi
                // foto_barangb
                // barang_b
                'users_id' => trim($valid['users_id']),
                'trips_id' => trim($valid['trips_id']),
                'catatan_lokasi' => trim($valid['catatan_lokasi']),
                'barangb' => trim($valid['barangb']),
                'foto_barangb' => trim($valid['foto_barangb']),
                'posisi_kursi' => trim($valid['posisi_kursi']),

            ]);

            $request = RequestTrip::where('trip_penumpangs_id', $id)->first()->update([
                'users_id' => trim($valid['users_id']),
                'trip_penumpangs_id' => trim($valid['trip_penumpangs_id']),
                'trips_id' => trim($valid['trips_id']),
                'tarif_rute_id' => trim($valid['tarif_rute_id']),
                'lokasi_penjeputan' => trim($valid['lokasi_penjemputan']),
                'barang_bawaan' => trim($valid['barang_bawaan']),
            ]);
        }
        catch (Exception $e) {
            DB::rollback();
            return response()->json([
                'code' => $e->getCode() ?? 500,
                'message' => 'Terjadi kesalahan!. ' . $e->getMessage()
            ], 200);
     }
    }
    public function tambahtrip(ApiTripRequest $request){
        $valid = $request->validated();
        // $this->registerValidation($request->all())
             Trip::create([
                // rute_perjalan
                // tanggal 
                // note_lokasi
                // note
                // kursi 
                // status

                'users_id' => trim($valid['users_id']),
                'tarifs_id' => trim($valid['tarifs_id']),
                'waktu' => trim($valid['waktu']),
                'status' => trim($valid['status']),
                'catatan' => trim($valid['catatan']),
                'tanggal' => trim($valid['tanggal']),
                'jam_keberangkatan' => trim($valid['jam_keberangkatan']),
                // 'jam_keb' => trim($valid['kapasitas']),
            ]);
            $trip_id = DB::getPdo()->lastInsertId();
            $trip_penumpang = TripPenumpang::create([
                'penumpang_trip_id'=>$trip_id
               
            ]);
            $posisi = DB::getPdo()->lastInsertId();
            $posisi_kursi = Posisi_kursi::create([
                'posisi_trips_id'=>$posisi
               
            ]);
            $request = DB::getPdo()->lastInsertId();
            $reauest_trip = Request::create([
                'request_id'=>$request
               
            ]);
            return response()->json([
                'code' => 200,
                'results' => [
                    'message' => 'Penumpang ' . $request->status
                ]
            ], 200);  
    }
    public function pembatalan(ApiPembatalanRequest $request, $id){
        $valid = $request->validated();
        // $this->registerValidation($request->all());
        DB::beginTransaction();
        try{
            $pembatalantrip = TripPenumpang::where('id', $id)->update([
                // rute_perjalan
                // tanggal 
                // note_lokasi
                // note
                // kursi 
                // status

                'users_id' => trim($valid['users_id']),
                'trips_id' => trim($valiarifs_id['trips_id']),
                'status' => trim($valid['status']),
                'alasan_pembatalan_id' => trim($valid['alasan_pembatalan_id']),
          
                // 'jam_keb' => trim($valid['kapasitas']),
            ]);
           
        }

        catch (Exception $e) {
            DB::rollback();
            return response()->json([
                'code' => $e->getCode() ?? 500,
                'message' => 'Terjadi kesalahan!. ' . $e->getMessage()
            ], 200);
     }
    }
}

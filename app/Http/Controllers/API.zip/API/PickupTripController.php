<?php

namespace App\Http\Controllers\API;
use App\Models\Pickuptrip;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\ApiPTripRequest;
use App\Http\Requests\APIPickupTtipPenumpang;
use App\Http\Requests\ApiPembatalanPickupRequest;
class PickupTripController extends Controller
{
    public function showpickuptrip(){
        $pickuptrip = Pickuptrip::get();
        return response()->json([
            'pickup_trips'=>$pickuptrip
        ]);
    }
    public function showpickuptrippenumpang(){
        $pickuptripp = PickupTripPenumpang::get();
        return response()->json([
            'pickup_trip_penumpangs'=>$pickuptripp
        ]);
    }

    public function tambahptrip(ApiPTripRequest $request){
        $valid = $request->validated();
        // $this->registerValidation($request->all());
        DB::beginTransaction();
        try{
            $ptrip = Pickuptrip::create([
                // rute_perjalan
                
                // tanggal 
                // waktu
                // jam
                // note_lokasi
                // note
          
                // status

                'users_id' => trim($valid['users_id']),
                'tarifs_id' => trim($valid['pickup_tarifs_id']),
                'waktu' => trim($valid['waktu']),
           
                'catatan_trip' => trim($valid['catatan_trip']),
                'note' => trim($valid['note']),
                'tanggal' => trim($valid['tanggal']),
                'jam_keberangkatan' => trim($valid['jam_keberangkatan']),
                // 'jam_keb' => trim($valid['kapasitas']),
            ]);


            $trip_id = DB::getPdo()->lastInsertId();
            $p_trip_penumpang = PickupTripPenumpang::create([
                'pickup_trip_penumpang_id'=>$p_trip_id
               
            ]);

            return response()->json([
                'code' => 200,
                'results' => [
                    'message' => 'Penumpang ' . $request->status
                ]
            ], 200);
          
         
        }
        catch (Exception $e) {
            DB::rollback();
            return response()->json([
                'code' => $e->getCode() ?? 500,
                'message' => 'Terjadi kesalahan!. ' . $e->getMessage()
            ], 200);
     }
    
     
    }

    public function tambahpickuptrippenumpang(APIPickupTtipPenumpang $request){
        $valid = $request->validated();
        // $this->registerValidation($request->all());
        DB::beginTransaction();
        try{

            if($request->file('foto')){
                $foto= $request->file('foto');
                $filename= 'PickupTripPenumpang-'. $foto->getClientOriginalName();
                $foto->move(public_path('inputan/img/pickup_trip_penumpang'), $filename);
            }
       
            $trip_penumpang = PickupTripPenumpang::create([
                // users_id
                // pick_uptrips_id
                // catatan_lokasi_jemout
                // cataatan_lokasi_antar
                // slot
                // foto
                // jenis_motor
                'users_id' => trim($valid['users_id']),
                'pickup_trips_id' => trim($valid['trips_id']),
                'note_lokasi_jemput' => trim($valid['note_lokasi_jemput']),
                'catatan_antar' => trim($valid['catatan_antar']),
                'jenis_motor_id' => trim($valid['jenis_motor_id']),
                'foto' => trim($valid['foto']),
                'posisi_kursi' => trim($valid['posisi_kursi']),
                'slot' => trim($valid['slot']),

            ]);

            $request = RequestTrip::where('pickup_trip_penumpangs_id', $id)->first()->update([
          
                'pickup_trip_penumpangs_id' => trim($valid['pickup_trip_penumpangs_id']),
                'pickup_trip_id' => trim($valid['pickup_trip_id']),
                'tarif_rute_id' => trim($valid['tarif_rute_id']),
                'lokasi_penjeputan' => trim($valid['lokasi_penjemputan']),
                'barang_bawaan' => trim($valid['barang_bawaan']),
                'fotob' => trim($valid['fotob']),
            ]);
        }
        
        catch (Exception $e) {
            DB::rollback();
            return response()->json([
                'code' => $e->getCode() ?? 500,
                'message' => 'Terjadi kesalahan!. ' . $e->getMessage()
            ], 200);
     }
    }

    public function pembatalan(ApiPembatalanPickupRequest $request, $id){
        $valid = $request->validated();
        // $this->registerValidation($request->all());
        DB::beginTransaction();
        try{
            $pembatalantrip = PickupTripPenumpang::where('id', $id)->update([
                // rute_perjalan
                // tanggal 
                // note_lokasi
                // note
                // kursi 
                // status

                'users_id' => trim($valid['users_id']),
                'pickup_trips_id' => trim($valiarifs_id['pickup_trips_id']),
                'status' => trim($valid['status']),
                'alasan_pembatalan_id' => trim($valid['alasan_pembatalan_id']),
          
                // 'jam_keb' => trim($valid['kapasitas']),
            ]);
           
        }

        catch (Exception $e) {
            DB::rollback();
            return response()->json([
                'code' => $e->getCode() ?? 500,
                'message' => 'Terjadi kesalahan!. ' . $e->getMessage()
            ], 200);
     }
    }
}

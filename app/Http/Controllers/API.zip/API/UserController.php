<?php

namespace App\Http\Controllers\API;
use App\Models\User;
use App\Models\DriverProfil;
use App\Models\PenumpangProfil;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\ApiPenumpangProfilRequest;
use App\Http\Requests\APIProfilDriverRequest;
use App\Http\Requests\APIUserRegisterRequest;

class UserController extends Controller
{
   //all response code is 200, permintaan hutomo


    public function showuser(){
        $user = User::get();
        return response()->json([
            'users'=>$user
        ]);
    }
    public function showuserdriver(){
        $userdriver = DriverProfil::get();
        return response()->json([
            'driverprofils'=>$userdriver  
        ]);
    }
    public function showuserpenumpang(){
        $userpenumpang = PenumpangProfil::get();
        return response()->json([
            'penumpang_profils'=>$userpenumpang
        ]);
    }

    // public function login(APILoginRequest $request){
    //     $valid = $request->validated();
    //     DB::beginTransaction();
    //     try  {

    //     }

    // }

    public function register(ApiUserRegisterRequest $request){
        $valid = $request->validated();
        // $this->registerValidation($request->all());
        DB::beginTransaction();
        try  {
 
            $user = User::create([
                'name' => trim($valid['name']),
                'email' => strtolower($valid['email']),
                'password' => $valid['password'],
                'no_hp' => $valid['no_hp'],
                'role' => $valid['role']
                
            ]);
            $akun_id = DB::getPdo()->lastInsertId();
            if ($user->role == "Driver"){
                DriverProfil::create([
                    'drivers_id'=>$akun_id
                ]);
        
               TotalSaldo::create([
                    'users_id'=>$akun_id
                ]);
            }
            DB::commit();
            return response()->json([
                'code' => 201,
                'message' => 'Berhasil menambahkan pengguna. Silahkan periksa e-mail yang terdaftar untuk aktivasi akun.'
            ]);  

        }
        catch (Exception $e) {
            DB::rollback();
            return response()->json([
                'code' => $e->getCode() ?? 500,
                'message' => 'Terjadi kesalahan!. ' . $e->getMessage()
            ], 200);
     }

    }
    public function mengeditprofil(APIProfilDriverRequest $request ,$id){
  
    $valid = $request->validated();
    // $this->registerValidation($request->all());
    DB::beginTransaction();
    try  {

        $user=User::where('users_id', $id)->first()->update([
             'name'=>trim($valid['name']),
             'no_hp'=>trim($valid['no_hp']),
         ]);

        $profil =DriverProfil::where('users_id' ,$id )->first()->update([
            'ktp' => trim($valid['ktp']),
            'kendaraan_id' => trim($valid['kendaraan_id']),
            'sim' => trim($valid['sim']),
            'stnk' => trim($valid['stnk']),
            'fotokendaraan1' => trim($valid['fotokendaraan1']),
            'fotokendaraan2' => trim($valid['fotokendaraan2']),
            'fotokendaraan3' => trim($valid['fotokendaraan3']),
            'fotokendaraan4' => trim($valid['fotokendaraan4']),
            'fotokendaraan5' => trim($valid['fotokendaraan5']),
            'tipe_pelayanan' => trim($valid['tipe_pelayanan']),
            'no_plat' =>trim($valid['no_plat']),
            
        ]);
       
        }
        catch (Exception $e) {
            DB::rollback();
            return response()->json([
                'code' => $e->getCode() ?? 500,
                'message' => 'Terjadi kesalahan!. ' . $e->getMessage()
            ], 200);
        
    }

    }

    public function mengeditprofilp(APIPenumpangProfilRequest $request ,$id){
  
        $valid = $request->validated();
        // $this->registerValidation($request->all());
        DB::beginTransaction();
        try  {
    
            if($request->file('identitas')){
                $identitas= $request->file('identitas');
                $filename= 'User-'. $bukti_barang->getClientOriginalName();
                $identitas->move(public_path('inputan/img/profilp'), $filename);
            }
       
            $user=User::where('users_id', $id)->first()->update([
                 'name'=>trim($valid['name']),
                  'email'=>trim($valid['email']),
                 'no_hp'=>trim($valid['no_hp']),
                 'identitas'=>trim($valid['identitas']),
             ]);
           
           
            }
            catch (Exception $e) {
                DB::rollback();
                return response()->json([
                    'code' => $e->getCode() ?? 500,
                    'message' => 'Terjadi kesalahan!. ' . $e->getMessage()
                ], 200);
            
        }
    
        }
    

}   

